﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decrypt
{
    public class Class1
    {

        dcFIPSLib.dcFIPSLib objdecrypt = new dcFIPSLib.dcFIPSLib();

        public string Decryption(string EncryptedValue)
        {
            try
            {
                if (!EncryptedValue.StartsWith("[secured]") && !EncryptedValue.EndsWith("[/secured]"))
                    return EncryptedValue;
                EncryptedValue = EncryptedValue.Replace("[secured]", "").Replace("[/secured]", "");

                string Key = DCKEY.Get(SampleCustom9.ObfusGater.Deencode(SampleCustom9.SKeys.SKNA[4]));
                String newValue = "";
                objdecrypt.Decrypt(EncryptedValue, out newValue, Key);

                string Key1 = DCKEY.Get(SampleCustom9.ObfusGater.Deencode(SampleCustom9.SKeys.SKNA[1]));
                String newValue1 = "";
                objdecrypt.Decrypt(EncryptedValue, out newValue1, Key1);

                string Key2 = DCKEY.Get(SampleCustom9.ObfusGater.Deencode(SampleCustom9.SKeys.SKNA[2]));
                String newValue2 = "";
                objdecrypt.Decrypt(EncryptedValue, out newValue2, Key2);

                string Key3 = DCKEY.Get(SampleCustom9.ObfusGater.Deencode(SampleCustom9.SKeys.SKNA[3]));
                String newValue3 = "";
                objdecrypt.Decrypt(EncryptedValue, out newValue3, Key3);

                string strreturnvalue = "";

                if (newValue != "")
                {
                    strreturnvalue = newValue;
                }
                else if (newValue1 != "")
                {
                    strreturnvalue = newValue1;
                }
                else if (newValue2 != "")
                {
                    strreturnvalue = newValue2;
                }
                else if (newValue3 != "")
                {
                    strreturnvalue = newValue3;
                }

                return strreturnvalue;
            }
            catch (Exception ex)
            {

                //TODO: don't swallow this exception, log it at least.
                return "";
            }
        }
        public dynamic DCKEY
        {
            get
            {
                return Activator.CreateInstance(Type.GetTypeFromProgID("dcKST.dcKey"));
            }
        }


        public dynamic DCFIPS
        {
            get
            {
                return new dcFIPSLib.dcFIPSLib();
                //return Activator.CreateInstance(Type.GetTypeFromProgID("dcFIPSLib.dcFIPSLibClass"));
            }
        }
    }
    

}
