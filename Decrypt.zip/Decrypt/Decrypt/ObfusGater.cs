﻿// Type: dcKST.ObfusGater
// Assembly: Datacap.Libraries.Nenu, Version=8.1.0.0, Culture=neutral, PublicKeyToken=e88d56f0d8a5c789
// MVID: E06D3450-1DAB-4218-8724-62D9FEF5963E
// Assembly location: C:\Datacap\dcshared\NET\Datacap.Libraries.Nenu.dll

using System;
using System.Runtime.InteropServices;

namespace SampleCustom9
{
  public class ObfusGater
  {
    private static int CharSizeInText;
    private static string alfavit;

    static ObfusGater()
    {
      ObfusGater.CharSizeInText = 3;
      ObfusGater.alfavit = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    }

    private static string IntTo62CodeString(int nVal, int nPosPad)
    {
      bool flag = 0 > nVal;
      if (flag)
        nVal *= -1;
      int length = ObfusGater.alfavit.Length;
      int num1 = 0;
      int num2 = 1;
      while (nVal / num2 != 0)
      {
        ++num1;
        num2 *= length;
      }
      if (0 < num1)
        num2 /= length;
      string str1 = flag ? "-" : "";
      string str2 = "";
      while (0 < num2)
      {
        int index = nVal / num2;
        str2 = str2 + (object) ObfusGater.alfavit[index];
        nVal -= index * num2;
        num2 /= length;
      }
      if (0 < nPosPad)
      {
        for (int index = nPosPad - num1; 0 < index; --index)
          str1 = str1 + (object) ObfusGater.alfavit[0];
      }
      return str1 + str2;
    }

    private static int String62CodeToInt(string strRsc)
    {
      int length1 = strRsc.Length;
      if (length1 == 0)
        return 0;
      int length2 = ObfusGater.alfavit.Length;
      ushort[] numArray = new ushort[128];
      for (int index = 0; index < length2; ++index)
      {
        char ch = ObfusGater.alfavit[index];
        numArray[(int) ch] = (ushort) ((int) ch - (65 > (int) ch ? 48 : (90 < (int) ch ? 61 : 55)));
      }
      bool flag = (int) strRsc[0] == 45;
      int num1 = 0;
      int num2 = flag ? 1 : 0;
      int index1 = length1 - 1;
      int num3 = 1;
      for (; num2 <= index1; --index1)
      {
        char ch = strRsc[index1];
        if ((int) ch <= (int) sbyte.MaxValue)
        {
          ushort num4 = numArray[(int) ch];
          num1 += (int) num4 * num3;
          num3 *= length2;
        }
      }
      if (flag)
        num1 *= -1;
      return num1;
    }

    private static string ApplyMask(string lpszSource, bool bEncrypt)
    {
      uint num1 = 16U;
      uint num2 = num1 * 16U / 64U;
      ulong[] numArray = new ulong[4]
      {
        12399108641032587247UL,
        10395942583446679290UL,
        8050801490262872325UL,
        6047635432676964368UL
      };
      string str1 = lpszSource;
      uint num3 = (uint) (str1.Length / (bEncrypt ? 1 : ObfusGater.CharSizeInText));
      if (num3 > 16U)
        return lpszSource;
      ObfusGater.myUNION myUnion = new ObfusGater.myUNION();
      myUnion.n64Val = new ulong[4];
      myUnion.ch = new char[17];
      for (int index = 0; (long) index < (long) num2; ++index)
        myUnion.n64Val[index] ^= numArray[index];
      if (bEncrypt)
      {
        for (int index = 0; (long) index < (long) num3; ++index)
          myUnion.ch[index] = str1[index];
      }
      else
      {
        for (int index = 0; (long) index < (long) num3; ++index)
          myUnion.ch[index] = (char) ObfusGater.String62CodeToInt(str1.Substring(index * ObfusGater.CharSizeInText, ObfusGater.CharSizeInText));
      }
      myUnion.ch[((IntPtr) num3).ToInt32()] = char.MinValue;
      uint num4 = (uint) myUnion.ch[0];
      uint num5 = 2U;
      uint num6 = num1 - num5;
      uint num7 = bEncrypt ? 3U : (uint) (192 << (int) num1 - 8);
      if (bEncrypt)
      {
        uint num8 = (int) num3 == 0 ? 0U : num4 & num7;
        for (uint index = 0U; index < num3; ++index)
        {
          myUnion.ch[((IntPtr) index).ToInt32()] >>= (int) num5;
          uint num9 = (index < num3 - 1U ? (uint) myUnion.ch[((IntPtr) (index + 1U)).ToInt32()] & num7 : num8) << (int) num6;
          myUnion.ch[((IntPtr) index).ToInt32()] |= (char) num9;
        }
      }
      for (int index = 0; (long) index < (long) num2; ++index)
        myUnion.n64Val[index] ^= numArray[index];
      myUnion.ch[((IntPtr) num3).ToInt32()] = char.MinValue;
      uint num10 = (uint) myUnion.ch[((IntPtr) (num3 - 1U)).ToInt32()];
      if (!bEncrypt)
      {
        uint num8 = (int) num3 == 0 ? 0U : num10 & num7;
        for (int index = (int) num3 - 1; index >= 0; --index)
        {
          myUnion.ch[index] <<= (int) num5;
          uint num9 = (index != 0 ? (uint) myUnion.ch[index - 1] & num7 : num8) >> (int) num6;
          myUnion.ch[index] |= (char) num9;
        }
      }
      string str2 = "";
      if (bEncrypt)
      {
        for (int index = 0; (long) index < (long) num3; ++index)
        {
          string str3 = ObfusGater.IntTo62CodeString((int) myUnion.ch[index], ObfusGater.CharSizeInText);
          str2 = str2 + str3;
        }
      }
      else
      {
        foreach (char ch in myUnion.ch)
        {
          if ((int) ch != 0)
            str2 = str2 + (object) ch;
          else
            break;
        }
      }
      return str2;
    }

    private static string ApplyOldTMMask(string lpszSource, bool bEncrypt)
    {
      uint num1 = 8U;
      uint num2 = num1 * 16U / 64U;
      ulong[] numArray = new ulong[2]
      {
        12399108641032587247UL,
        12399108641032587247UL
      };
      string str1 = lpszSource;
      uint num3 = (uint) (str1.Length / (bEncrypt ? 1 : ObfusGater.CharSizeInText));
      if (num3 > 16U)
        return lpszSource;
      ObfusGater.myoldtmUNION myoldtmUnion = new ObfusGater.myoldtmUNION();
      myoldtmUnion.n64Val = new ulong[2];
      myoldtmUnion.ch = new byte[17];
      for (int index = 0; (long) index < (long) num2; ++index)
        myoldtmUnion.n64Val[index] ^= numArray[index];
      if (bEncrypt)
      {
        for (int index = 0; (long) index < (long) num3; ++index)
          myoldtmUnion.ch[index] = (byte) str1[index];
      }
      else
      {
        for (int index = 0; (long) index < (long) num3; ++index)
          myoldtmUnion.ch[index] = byte.Parse(str1.Substring(index * ObfusGater.CharSizeInText, ObfusGater.CharSizeInText));
      }
      myoldtmUnion.ch[((IntPtr) num3).ToInt32()] = (byte) 0;
      uint num4 = (uint) myoldtmUnion.ch[0];
      uint num5 = 2U;
      uint num6 = num1 - num5;
      uint num7 = bEncrypt ? 3U : (uint) (192 << (int) num1 - 8);
      if (bEncrypt)
      {
        uint num8 = (int) num3 == 0 ? 0U : num4 & num7;
        for (uint index = 0U; index < num3; ++index)
        {
          myoldtmUnion.ch[((IntPtr) index).ToInt32()] >>= (int) num5;
          uint num9 = (index < num3 - 1U ? (uint) myoldtmUnion.ch[((IntPtr) (index + 1U)).ToInt32()] & num7 : num8) << (int) num6;
          myoldtmUnion.ch[((IntPtr) index).ToInt32()] |= (byte) num9;
        }
      }
      for (int index = 0; (long) index < (long) num2; ++index)
        myoldtmUnion.n64Val[index] ^= numArray[index];
      myoldtmUnion.ch[((IntPtr) num3).ToInt32()] = (byte) 0;
      uint num10 = (uint) myoldtmUnion.ch[((IntPtr) (num3 - 1U)).ToInt32()];
      if (!bEncrypt)
      {
        uint num8 = (int) num3 == 0 ? 0U : num10 & num7;
        for (int index = (int) num3 - 1; index >= 0; --index)
        {
          myoldtmUnion.ch[index] <<= (int) num5;
          uint num9 = (index != 0 ? (uint) myoldtmUnion.ch[index - 1] & num7 : num8) >> (int) num6;
          myoldtmUnion.ch[index] |= (byte) num9;
        }
      }
      string str2 = "";
      if (bEncrypt)
      {
        for (int index = 0; (long) index < (long) num3; ++index)
        {
          string str3 = string.Format("{0}", (object) myoldtmUnion.ch[index].ToString("000"));
          str2 = str2 + str3;
        }
      }
      else
      {
        foreach (char ch in myoldtmUnion.ch)
        {
          if ((int) ch != 0)
            str2 = str2 + (object) ch;
          else
            break;
        }
      }
      return str2;
    }

    internal static byte[] String62ToByteArray(string strIN62)
    {
      byte[] numArray = new byte[strIN62.Length];
      bool flag = true;
      for (int index = 0; index < strIN62.Length; ++index)
      {
        numArray[index] = !flag ? (byte) ((uint) strIN62[index] << 1) : (byte) ((uint) strIN62[index] - 48U);
        flag = !flag;
      }
      return numArray;
    }

    internal static string ByteArray2String62(byte[] ba)
    {
      string str = "";
      try
      {
        bool flag = true;
        for (int index = 0; index < ba.Length; ++index)
        {
          str = !flag ? str + (object) (char) ((uint) ba[index] >> 1) : str + (object) (char) ((uint) ba[index] + 48U);
          flag = !flag;
        }
      }
      catch (Exception ex)
      {
        str = (string) null;
      }
      return str;
    }

    internal static string _encode(string lpszSource, bool bOldTM)
    {
      string str1 = lpszSource;
      string str2 = "";
      int length = str1.Length;
      while (0 < length)
      {
        int num = 15 < length ? 16 : length;
        str2 = str2 + (bOldTM ? ObfusGater.ApplyOldTMMask(str1.Substring(0, num), true) : ObfusGater.ApplyMask(str1.Substring(0, num), true));
        str1 = str1.Substring(num);
        length -= num;
      }
      return str2;
    }

    internal static string _deencode(string lpszSource, bool bOldTM)
    {
      string str1 = lpszSource;
      string str2 = "";
      int num1 = str1.Length / ObfusGater.CharSizeInText;
      while (0 < num1)
      {
        int num2 = 15 < num1 ? 16 : num1;
        str2 = str2 + (bOldTM ? ObfusGater.ApplyOldTMMask(str1.Substring(0, num2 * ObfusGater.CharSizeInText), false) : ObfusGater.ApplyMask(str1.Substring(0, num2 * ObfusGater.CharSizeInText), false));
        str1 = str1.Substring(num2 * ObfusGater.CharSizeInText);
        num1 -= num2;
      }
      return str2;
    }

    internal static string Encode(string lpszSource)
    {
      return ObfusGater._encode(lpszSource, false);
    }

    internal static string Deencode(string lpszSource)
    {
      return ObfusGater._deencode(lpszSource, false);
    }

    internal static string Deencode(byte[] ba)
    {
      string lpszSource = ObfusGater.ByteArray2String62(ba);
      if (lpszSource == null)
        return "";
      else
        return ObfusGater.Deencode(lpszSource);
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct myUNION
    {
      [FieldOffset(0)]
      public ulong[] n64Val;
      [FieldOffset(0)]
      public char[] ch;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct myoldtmUNION
    {
      [FieldOffset(0)]
      public ulong[] n64Val;
      [FieldOffset(0)]
      public byte[] ch;
    }
  }
}
